import React from 'react'
import { Link } from 'react-router-dom'

const Logo = ({ size = 'md', showText = true, linkTo = '/', className = '' }) => {
  const sizeClasses = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-12 h-12',
    xl: 'w-16 h-16'
  }

  const textSizeClasses = {
    sm: 'text-lg',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl'
  }

  const LogoSVG = () => (
    <div className={`${sizeClasses[size]} relative`}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Outer yellow circle */}
        <circle
          cx="50"
          cy="50"
          r="48"
          fill="none"
          stroke="#F59E0B"
          strokeWidth="4"
        />
        
        {/* Black "H" shape */}
        <path
          d="M20 25 L20 55 L35 55 L35 45 L65 45 L65 55 L80 55 L80 25 L65 25 L65 35 L35 35 L35 25 Z"
          fill="#000000"
        />
        
        {/* Gray bottom section */}
        <path
          d="M20 55 Q50 75 80 55 L80 75 Q50 85 20 75 Z"
          fill="#D1D5DB"
        />
        
        {/* Yellow "PLUS" text */}
        <text
          x="50"
          y="70"
          textAnchor="middle"
          fontSize="8"
          fill="#F59E0B"
          fontWeight="bold"
          fontFamily="Arial, sans-serif"
        >
          PLUS
        </text>
      </svg>
    </div>
  )

  const content = (
    <div className={`flex items-center space-x-2 ${className}`}>
      <LogoSVG />
      {showText && (
        <div className="flex flex-col">
          <span className={`${textSizeClasses[size]} font-bold text-text leading-none`}>
            Hitcharide
          </span>
          <span className="text-xs text-textSecondary uppercase tracking-wider">
            Rentals LLC
          </span>
        </div>
      )}
    </div>
  )

  if (linkTo) {
    return (
      <Link to={linkTo} className="hover:opacity-80 transition-opacity">
        {content}
      </Link>
    )
  }

  return content
}

export default Logo
