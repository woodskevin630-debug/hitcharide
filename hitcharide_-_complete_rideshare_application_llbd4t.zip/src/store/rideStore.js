import { create } from 'zustand'

export const useRideStore = create((set, get) => ({
  currentRide: null,
  rideHistory: [],
  availableDrivers: [],
  isBooking: false,
  
  bookRide: async (rideData) => {
    set({ isBooking: true })
    try {
      const response = await fetch('/api/rides/book', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${get().token}`
        },
        body: JSON.stringify(rideData)
      })
      
      const data = await response.json()
      
      if (response.ok) {
        set({ currentRide: data.ride, isBooking: false })
        return { success: true, ride: data.ride }
      } else {
        set({ isBooking: false })
        return { success: false, error: data.message }
      }
    } catch (error) {
      set({ isBooking: false })
      return { success: false, error: 'Network error' }
    }
  },

  updateRideStatus: (rideId, status) => {
    set(state => ({
      currentRide: state.currentRide?.id === rideId 
        ? { ...state.currentRide, status }
        : state.currentRide
    }))
  },

  setAvailableDrivers: (drivers) => {
    set({ availableDrivers: drivers })
  },

  clearCurrentRide: () => {
    set({ currentRide: null })
  }
}))
