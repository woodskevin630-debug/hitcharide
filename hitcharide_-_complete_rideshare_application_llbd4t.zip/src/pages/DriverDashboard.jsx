import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Car, DollarSign, Clock, Star, MapPin, Phone, Navigation, CheckCircle, ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'
import Logo from '../components/Logo'

const DriverDashboard = () => {
  const [isOnline, setIsOnline] = useState(false)
  const [currentRide, setCurrentRide] = useState(null)

  const stats = [
    { label: 'Today\'s Earnings', value: '$127.50', icon: <DollarSign className="w-6 h-6" /> },
    { label: 'Rides Completed', value: '8', icon: <Car className="w-6 h-6" /> },
    { label: 'Hours Online', value: '6.5', icon: <Clock className="w-6 h-6" /> },
    { label: 'Rating', value: '4.9', icon: <Star className="w-6 h-6" /> }
  ]

  const rideRequests = [
    {
      id: 1,
      passenger: 'John Smith',
      pickup: '123 Main St',
      destination: '456 Oak Ave',
      distance: '2.3 miles',
      fare: '$12.50',
      rating: 4.8
    },
    {
      id: 2,
      passenger: 'Lisa Johnson',
      pickup: '789 Pine St',
      destination: '321 Elm St',
      distance: '1.8 miles',
      fare: '$9.75',
      rating: 5.0
    }
  ]

  const acceptRide = (ride) => {
    setCurrentRide(ride)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/dashboard" className="p-2 hover:bg-background rounded-xl transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </Link>
            <Logo size="sm" linkTo="/dashboard" />
            <div>
              <h1 className="text-xl font-bold">Driver Dashboard</h1>
              <p className="text-textSecondary text-sm">Manage your rides and earnings</p>
            </div>
          </div>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <span className="text-textSecondary">Status:</span>
              <button
                onClick={() => setIsOnline(!isOnline)}
                className={`px-4 py-2 rounded-full font-medium transition-colors ${
                  isOnline 
                    ? 'bg-success text-white' 
                    : 'bg-surface text-textSecondary border border-border'
                }`}
              >
                {isOnline ? 'Online' : 'Offline'}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="max-w-7xl mx-auto">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="card"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <div className="flex items-center space-x-4">
                  <div className="p-3 bg-primary/10 rounded-2xl text-primary">
                    {stat.icon}
                  </div>
                  <div>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-textSecondary text-sm">{stat.label}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Current Ride */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Current Ride</h2>
              {currentRide ? (
                <motion.div
                  className="card gradient-bg text-white"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold">Active Ride</h3>
                    <span className="bg-white/20 px-3 py-1 rounded-full text-sm">
                      In Progress
                    </span>
                  </div>
                  
                  <div className="space-y-4">
                    <div>
                      <p className="opacity-90 mb-1">Passenger</p>
                      <p className="text-lg font-semibold">{currentRide.passenger}</p>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <p className="opacity-90 mb-1">Pickup</p>
                        <p className="font-medium">{currentRide.pickup}</p>
                      </div>
                      <div>
                        <p className="opacity-90 mb-1">Destination</p>
                        <p className="font-medium">{currentRide.destination}</p>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t border-white/20">
                      <span className="text-lg font-bold">{currentRide.fare}</span>
                      <div className="flex space-x-2">
                        <button className="bg-white/20 p-2 rounded-full">
                          <Phone className="w-5 h-5" />
                        </button>
                        <button className="bg-white/20 p-2 rounded-full">
                          <Navigation className="w-5 h-5" />
                        </button>
                        <button 
                          onClick={() => setCurrentRide(null)}
                          className="bg-success p-2 rounded-full"
                        >
                          <CheckCircle className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                </motion.div>
              ) : (
                <div className="card text-center py-12">
                  <Car className="w-16 h-16 text-textSecondary mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Active Ride</h3>
                  <p className="text-textSecondary">
                    {isOnline ? 'Waiting for ride requests...' : 'Go online to start receiving rides'}
                  </p>
                </div>
              )}
            </div>

            {/* Ride Requests */}
            <div>
              <h2 className="text-2xl font-bold mb-6">Ride Requests</h2>
              {isOnline && !currentRide ? (
                <div className="space-y-4">
                  {rideRequests.map((ride) => (
                    <motion.div
                      key={ride.id}
                      className="card border-2 border-primary/20"
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                    >
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center space-x-3">
                          <div className="w-10 h-10 bg-primary/10 rounded-full flex items-center justify-center">
                            <span className="font-semibold text-primary">
                              {ride.passenger.split(' ').map(n => n[0]).join('')}
                            </span>
                          </div>
                          <div>
                            <h4 className="font-semibold">{ride.passenger}</h4>
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 text-warning fill-current" />
                              <span className="text-sm text-textSecondary">{ride.rating}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-xl font-bold text-primary">{ride.fare}</p>
                          <p className="text-textSecondary text-sm">{ride.distance}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-2 mb-4">
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-success rounded-full"></div>
                          <span className="text-sm">{ride.pickup}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <div className="w-3 h-3 bg-error rounded-full"></div>
                          <span className="text-sm">{ride.destination}</span>
                        </div>
                      </div>
                      
                      <div className="flex space-x-3">
                        <button className="btn-secondary flex-1">
                          Decline
                        </button>
                        <button 
                          onClick={() => acceptRide(ride)}
                          className="btn-primary flex-1"
                        >
                          Accept
                        </button>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="card text-center py-12">
                  <MapPin className="w-16 h-16 text-textSecondary mx-auto mb-4" />
                  <h3 className="text-xl font-semibold mb-2">No Requests</h3>
                  <p className="text-textSecondary">
                    {!isOnline 
                      ? 'Go online to start receiving ride requests'
                      : currentRide 
                        ? 'Complete your current ride to receive new requests'
                        : 'No ride requests at the moment'
                    }
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default DriverDashboard
