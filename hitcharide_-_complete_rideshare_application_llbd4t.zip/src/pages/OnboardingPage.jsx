import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { Car, MapPin, CreditCard, Shield, CheckCircle, ArrowRight, ArrowLeft } from 'lucide-react'
import { useAuthStore } from '../store/authStore'

const OnboardingPage = () => {
  const [currentStep, setCurrentStep] = useState(0)
  const { user, updateUser } = useAuthStore()
  const navigate = useNavigate()

  const steps = [
    {
      id: 'welcome',
      title: 'Welcome to Hitcharide!',
      description: 'Let\'s get you set up for the best ride experience',
      icon: <Car className="w-12 h-12" />,
      component: WelcomeStep
    },
    {
      id: 'location',
      title: 'Enable Location Services',
      description: 'We need your location to find nearby drivers and provide accurate ETAs',
      icon: <MapPin className="w-12 h-12" />,
      component: LocationStep
    },
    {
      id: 'payment',
      title: 'Add Payment Method',
      description: 'Add a payment method for seamless ride payments',
      icon: <CreditCard className="w-12 h-12" />,
      component: PaymentStep
    },
    {
      id: 'safety',
      title: 'Safety Features',
      description: 'Learn about our safety features to ensure secure rides',
      icon: <Shield className="w-12 h-12" />,
      component: SafetyStep
    },
    {
      id: 'complete',
      title: 'You\'re All Set!',
      description: 'Welcome to the Hitcharide community. Let\'s get you moving!',
      icon: <CheckCircle className="w-12 h-12" />,
      component: CompleteStep
    }
  ]

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      updateUser({ onboardingCompleted: true })
      navigate('/dashboard')
    }
  }

  const prevStep = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1)
    }
  }

  const CurrentStepComponent = steps[currentStep].component

  return (
    <div className="min-h-screen flex items-center justify-center px-4 sm:px-6 lg:px-8">
      <div className="max-w-2xl w-full">
        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <span className="text-sm text-textSecondary">
              Step {currentStep + 1} of {steps.length}
            </span>
            <span className="text-sm text-textSecondary">
              {Math.round(((currentStep + 1) / steps.length) * 100)}% Complete
            </span>
          </div>
          <div className="w-full bg-surface rounded-full h-2">
            <motion.div
              className="gradient-bg h-2 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
        </div>

        {/* Step Content */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
            className="card text-center"
          >
            <div className="text-primary mb-6 flex justify-center">
              {steps[currentStep].icon}
            </div>
            
            <h1 className="text-3xl font-bold mb-4">
              {steps[currentStep].title}
            </h1>
            
            <p className="text-textSecondary text-lg mb-8">
              {steps[currentStep].description}
            </p>

            <CurrentStepComponent onNext={nextStep} />
          </motion.div>
        </AnimatePresence>

        {/* Navigation */}
        <div className="flex justify-between items-center mt-8">
          <button
            onClick={prevStep}
            disabled={currentStep === 0}
            className={`flex items-center space-x-2 px-6 py-3 rounded-2xl transition-all ${
              currentStep === 0
                ? 'text-textSecondary cursor-not-allowed'
                : 'text-text hover:bg-surface'
            }`}
          >
            <ArrowLeft className="w-5 h-5" />
            <span>Back</span>
          </button>

          <button
            onClick={nextStep}
            className="btn-primary flex items-center space-x-2"
          >
            <span>{currentStep === steps.length - 1 ? 'Get Started' : 'Continue'}</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  )
}

// Step Components
function WelcomeStep({ onNext }) {
  return (
    <div className="space-y-6">
      <div className="text-left space-y-4">
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-6 h-6 text-success" />
          <span>Instant ride booking</span>
        </div>
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-6 h-6 text-success" />
          <span>Real-time driver tracking</span>
        </div>
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-6 h-6 text-success" />
          <span>Secure payment processing</span>
        </div>
        <div className="flex items-center space-x-3">
          <CheckCircle className="w-6 h-6 text-success" />
          <span>24/7 customer support</span>
        </div>
      </div>
    </div>
  )
}

function LocationStep({ onNext }) {
  const [locationEnabled, setLocationEnabled] = useState(false)

  const enableLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocationEnabled(true)
          setTimeout(onNext, 1000)
        },
        (error) => {
          console.error('Location error:', error)
          // For demo purposes, we'll proceed anyway
          setLocationEnabled(true)
          setTimeout(onNext, 1000)
        }
      )
    }
  }

  return (
    <div className="space-y-6">
      {!locationEnabled ? (
        <button
          onClick={enableLocation}
          className="btn-primary w-full"
        >
          Enable Location Services
        </button>
      ) : (
        <div className="text-success flex items-center justify-center space-x-2">
          <CheckCircle className="w-6 h-6" />
          <span>Location services enabled!</span>
        </div>
      )}
      
      <div className="text-sm text-textSecondary">
        <p>We use your location to:</p>
        <ul className="list-disc list-inside mt-2 space-y-1">
          <li>Find nearby drivers</li>
          <li>Provide accurate pickup locations</li>
          <li>Calculate precise ETAs</li>
          <li>Optimize your route</li>
        </ul>
      </div>
    </div>
  )
}

function PaymentStep({ onNext }) {
  const [paymentAdded, setPaymentAdded] = useState(false)

  const addPayment = () => {
    // Simulate adding payment method
    setPaymentAdded(true)
    setTimeout(onNext, 1000)
  }

  return (
    <div className="space-y-6">
      {!paymentAdded ? (
        <div className="space-y-4">
          <button
            onClick={addPayment}
            className="btn-primary w-full"
          >
            Add Credit/Debit Card
          </button>
          
          <div className="text-center text-textSecondary">
            <p>or</p>
          </div>
          
          <button
            onClick={addPayment}
            className="btn-secondary w-full"
          >
            Connect PayPal
          </button>
        </div>
      ) : (
        <div className="text-success flex items-center justify-center space-x-2">
          <CheckCircle className="w-6 h-6" />
          <span>Payment method added!</span>
        </div>
      )}
      
      <div className="text-sm text-textSecondary">
        <p>Your payment information is:</p>
        <ul className="list-disc list-inside mt-2 space-y-1">
          <li>Encrypted and secure</li>
          <li>Never shared with drivers</li>
          <li>Processed by trusted partners</li>
          <li>Can be updated anytime</li>
        </ul>
      </div>
    </div>
  )
}

function SafetyStep({ onNext }) {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
        <div className="p-4 bg-background rounded-2xl">
          <Shield className="w-8 h-8 text-primary mb-2" />
          <h3 className="font-semibold mb-2">Driver Verification</h3>
          <p className="text-sm text-textSecondary">All drivers undergo background checks and vehicle inspections</p>
        </div>
        
        <div className="p-4 bg-background rounded-2xl">
          <MapPin className="w-8 h-8 text-primary mb-2" />
          <h3 className="font-semibold mb-2">Trip Sharing</h3>
          <p className="text-sm text-textSecondary">Share your trip details with trusted contacts in real-time</p>
        </div>
        
        <div className="p-4 bg-background rounded-2xl">
          <Car className="w-8 h-8 text-primary mb-2" />
          <h3 className="font-semibold mb-2">Emergency Button</h3>
          <p className="text-sm text-textSecondary">Quick access to emergency services and support</p>
        </div>
        
        <div className="p-4 bg-background rounded-2xl">
          <CheckCircle className="w-8 h-8 text-primary mb-2" />
          <h3 className="font-semibold mb-2">Insurance Coverage</h3>
          <p className="text-sm text-textSecondary">Every ride is covered by comprehensive insurance</p>
        </div>
      </div>
      
      <button
        onClick={onNext}
        className="btn-primary w-full"
      >
        I Understand
      </button>
    </div>
  )
}

function CompleteStep({ onNext }) {
  return (
    <div className="space-y-6">
      <div className="text-6xl mb-6">🎉</div>
      
      <div className="space-y-4">
        <p className="text-lg">
          You're now part of the Hitcharide community! Here's what you can do:
        </p>
        
        <div className="text-left space-y-3">
          <div className="flex items-center space-x-3">
            <Car className="w-5 h-5 text-primary" />
            <span>Book your first ride</span>
          </div>
          <div className="flex items-center space-x-3">
            <MapPin className="w-5 h-5 text-primary" />
            <span>Set favorite locations</span>
          </div>
          <div className="flex items-center space-x-3">
            <CreditCard className="w-5 h-5 text-primary" />
            <span>Manage payment methods</span>
          </div>
          <div className="flex items-center space-x-3">
            <Shield className="w-5 h-5 text-primary" />
            <span>Access safety features</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default OnboardingPage
