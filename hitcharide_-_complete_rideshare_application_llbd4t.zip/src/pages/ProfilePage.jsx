import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { User, Mail, Phone, MapPin, CreditCard, Shield, Bell, Settings, Edit, Camera, ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useAuthStore } from '../store/authStore'
import Logo from '../components/Logo'

const ProfilePage = () => {
  const [activeTab, setActiveTab] = useState('profile')
  const { user, updateUser } = useAuthStore()
  const [isEditing, setIsEditing] = useState(false)
  const [formData, setFormData] = useState({
    firstName: user?.firstName || '',
    lastName: user?.lastName || '',
    email: user?.email || '',
    phone: user?.phone || ''
  })

  const tabs = [
    { id: 'profile', label: 'Profile', icon: <User className="w-5 h-5" /> },
    { id: 'payment', label: 'Payment', icon: <CreditCard className="w-5 h-5" /> },
    { id: 'safety', label: 'Safety', icon: <Shield className="w-5 h-5" /> },
    { id: 'notifications', label: 'Notifications', icon: <Bell className="w-5 h-5" /> },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" /> }
  ]

  const handleSave = () => {
    updateUser(formData)
    setIsEditing(false)
  }

  const paymentMethods = [
    {
      id: 1,
      type: 'Visa',
      last4: '4242',
      expiry: '12/26',
      isDefault: true
    },
    {
      id: 2,
      type: 'Mastercard',
      last4: '8888',
      expiry: '09/25',
      isDefault: false
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border px-4 py-4">
        <div className="flex items-center space-x-4">
          <Link to="/dashboard" className="p-2 hover:bg-background rounded-xl transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <Logo size="sm" linkTo="/dashboard" />
          <div>
            <h1 className="text-xl font-bold">Profile</h1>
            <p className="text-textSecondary text-sm">Manage your account and preferences</p>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="card p-0 overflow-hidden">
                <div className="p-6 text-center border-b border-border">
                  <div className="relative inline-block mb-4">
                    <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center text-white text-2xl font-bold">
                      {user?.firstName?.[0]}{user?.lastName?.[0]}
                    </div>
                    <button className="absolute -bottom-1 -right-1 w-8 h-8 bg-surface border-2 border-background rounded-full flex items-center justify-center hover:bg-primary hover:text-white transition-colors">
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                  <h3 className="font-semibold text-lg">{user?.firstName} {user?.lastName}</h3>
                  <p className="text-textSecondary text-sm">{user?.email}</p>
                </div>
                
                <nav className="p-2">
                  {tabs.map((tab) => (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-2xl transition-colors ${
                        activeTab === tab.id
                          ? 'bg-primary text-white'
                          : 'hover:bg-background text-textSecondary hover:text-text'
                      }`}
                    >
                      {tab.icon}
                      <span>{tab.label}</span>
                    </button>
                  ))}
                </nav>
              </div>
            </div>

            {/* Content */}
            <div className="lg:col-span-3">
              <motion.div
                key={activeTab}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
              >
                {activeTab === 'profile' && (
                  <div className="card">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold">Personal Information</h2>
                      <button
                        onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                        className="btn-primary flex items-center space-x-2"
                      >
                        <Edit className="w-4 h-4" />
                        <span>{isEditing ? 'Save' : 'Edit'}</span>
                      </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label className="block text-sm font-medium mb-2">First Name</label>
                        <div className="relative">
                          <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
                          <input
                            type="text"
                            value={formData.firstName}
                            onChange={(e) => setFormData({...formData, firstName: e.target.value})}
                            disabled={!isEditing}
                            className="input-field pl-12 w-full disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Last Name</label>
                        <input
                          type="text"
                          value={formData.lastName}
                          onChange={(e) => setFormData({...formData, lastName: e.target.value})}
                          disabled={!isEditing}
                          className="input-field w-full disabled:opacity-50"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Email</label>
                        <div className="relative">
                          <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
                          <input
                            type="email"
                            value={formData.email}
                            onChange={(e) => setFormData({...formData, email: e.target.value})}
                            disabled={!isEditing}
                            className="input-field pl-12 w-full disabled:opacity-50"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-medium mb-2">Phone</label>
                        <div className="relative">
                          <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
                          <input
                            type="tel"
                            value={formData.phone}
                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                            disabled={!isEditing}
                            className="input-field pl-12 w-full disabled:opacity-50"
                          />
                        </div>
                      </div>
                    </div>

                    <div className="mt-8 pt-6 border-t border-border">
                      <h3 className="text-lg font-semibold mb-4">Account Stats</h3>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-4 bg-background rounded-2xl">
                          <p className="text-2xl font-bold text-primary">47</p>
                          <p className="text-textSecondary text-sm">Total Rides</p>
                        </div>
                        <div className="p-4 bg-background rounded-2xl">
                          <p className="text-2xl font-bold text-success">4.9</p>
                          <p className="text-textSecondary text-sm">Average Rating</p>
                        </div>
                        <div className="p-4 bg-background rounded-2xl">
                          <p className="text-2xl font-bold text-warning">$342</p>
                          <p className="text-textSecondary text-sm">Total Spent</p>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'payment' && (
                  <div className="card">
                    <div className="flex items-center justify-between mb-6">
                      <h2 className="text-2xl font-bold">Payment Methods</h2>
                      <button className="btn-primary">Add New Card</button>
                    </div>

                    <div className="space-y-4">
                      {paymentMethods.map((method) => (
                        <div key={method.id} className="p-4 border border-border rounded-2xl">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                                <CreditCard className="w-6 h-6 text-primary" />
                              </div>
                              <div>
                                <h4 className="font-semibold">{method.type} •••• {method.last4}</h4>
                                <p className="text-textSecondary text-sm">Expires {method.expiry}</p>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              {method.isDefault && (
                                <span className="bg-success/10 text-success px-3 py-1 rounded-full text-sm">
                                  Default
                                </span>
                              )}
                              <button className="text-textSecondary hover:text-text">
                                <Edit className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {activeTab === 'safety' && (
                  <div className="card">
                    <h2 className="text-2xl font-bold mb-6">Safety & Security</h2>
                    
                    <div className="space-y-6">
                      <div className="p-4 border border-border rounded-2xl">
                        <h3 className="font-semibold mb-2">Emergency Contacts</h3>
                        <p className="text-textSecondary text-sm mb-4">
                          Add trusted contacts who can be notified in case of emergency
                        </p>
                        <button className="btn-secondary">Manage Contacts</button>
                      </div>

                      <div className="p-4 border border-border rounded-2xl">
                        <h3 className="font-semibold mb-2">Trip Sharing</h3>
                        <p className="text-textSecondary text-sm mb-4">
                          Automatically share your trip details with trusted contacts
                        </p>
                        <label className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" defaultChecked />
                          <span>Enable automatic trip sharing</span>
                        </label>
                      </div>

                      <div className="p-4 border border-border rounded-2xl">
                        <h3 className="font-semibold mb-2">Two-Factor Authentication</h3>
                        <p className="text-textSecondary text-sm mb-4">
                          Add an extra layer of security to your account
                        </p>
                        <button className="btn-primary">Enable 2FA</button>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'notifications' && (
                  <div className="card">
                    <h2 className="text-2xl font-bold mb-6">Notification Preferences</h2>
                    
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold mb-4">Push Notifications</h3>
                        <div className="space-y-3">
                          <label className="flex items-center justify-between">
                            <span>Ride updates</span>
                            <input type="checkbox" className="rounded" defaultChecked />
                          </label>
                          <label className="flex items-center justify-between">
                            <span>Driver arrival notifications</span>
                            <input type="checkbox" className="rounded" defaultChecked />
                          </label>
                          <label className="flex items-center justify-between">
                            <span>Promotional offers</span>
                            <input type="checkbox" className="rounded" />
                          </label>
                        </div>
                      </div>

                      <div>
                        <h3 className="font-semibold mb-4">Email Notifications</h3>
                        <div className="space-y-3">
                          <label className="flex items-center justify-between">
                            <span>Ride receipts</span>
                            <input type="checkbox" className="rounded" defaultChecked />
                          </label>
                          <label className="flex items-center justify-between">
                            <span>Weekly summaries</span>
                            <input type="checkbox" className="rounded" defaultChecked />
                          </label>
                          <label className="flex items-center justify-between">
                            <span>Marketing emails</span>
                            <input type="checkbox" className="rounded" />
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {activeTab === 'settings' && (
                  <div className="card">
                    <h2 className="text-2xl font-bold mb-6">App Settings</h2>
                    
                    <div className="space-y-6">
                      <div>
                        <h3 className="font-semibold mb-4">Preferences</h3>
                        <div className="space-y-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">Default Pickup Location</label>
                            <div className="relative">
                              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
                              <input
                                type="text"
                                placeholder="Set your home address"
                                className="input-field pl-12 w-full"
                              />
                            </div>
                          </div>
                          
                          <div>
                            <label className="block text-sm font-medium mb-2">Preferred Ride Type</label>
                            <select className="input-field w-full">
                              <option>Standard</option>
                              <option>Economy</option>
                              <option>Premium</option>
                              <option>XL</option>
                            </select>
                          </div>
                        </div>
                      </div>

                      <div className="pt-6 border-t border-border">
                        <h3 className="font-semibold mb-4 text-error">Danger Zone</h3>
                        <div className="space-y-3">
                          <button className="btn-secondary w-full text-left">
                            Download My Data
                          </button>
                          <button className="btn-secondary w-full text-left text-error">
                            Delete Account
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default ProfilePage
