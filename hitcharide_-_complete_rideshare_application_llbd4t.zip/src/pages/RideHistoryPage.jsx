import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Car, Star, MapPin, Clock, DollarSign, Filter, Search, ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'
import Logo from '../components/Logo'

const RideHistoryPage = () => {
  const [searchTerm, setSearchTerm] = useState('')
  const [filterType, setFilterType] = useState('all')

  const rideHistory = [
    {
      id: 1,
      date: '2025-01-15',
      time: '6:30 PM',
      from: 'Downtown Office',
      to: 'Home',
      driver: 'Sarah Johnson',
      fare: 12.50,
      rating: 5,
      status: 'completed',
      duration: '18 min',
      distance: '4.2 miles'
    },
    {
      id: 2,
      date: '2025-01-14',
      time: '2:15 PM',
      from: 'Airport',
      to: 'Hotel Plaza',
      driver: 'Michael Chen',
      fare: 28.75,
      rating: 4,
      status: 'completed',
      duration: '35 min',
      distance: '12.8 miles'
    },
    {
      id: 3,
      date: '2025-01-13',
      time: '7:45 PM',
      from: 'Shopping Mall',
      to: 'Restaurant',
      driver: 'Emily Rodriguez',
      fare: 8.25,
      rating: 5,
      status: 'completed',
      duration: '12 min',
      distance: '2.1 miles'
    },
    {
      id: 4,
      date: '2025-01-12',
      time: '9:00 AM',
      from: 'Home',
      to: 'Medical Center',
      driver: 'David Kim',
      fare: 15.90,
      rating: 4,
      status: 'completed',
      duration: '22 min',
      distance: '6.7 miles'
    },
    {
      id: 5,
      date: '2025-01-11',
      time: '11:30 PM',
      from: 'Concert Hall',
      to: 'Home',
      driver: 'Lisa Wang',
      fare: 18.40,
      rating: 5,
      status: 'completed',
      duration: '28 min',
      distance: '8.3 miles'
    },
    {
      id: 6,
      date: '2025-01-10',
      time: '3:20 PM',
      from: 'University',
      to: 'Coffee Shop',
      driver: 'James Wilson',
      fare: 6.75,
      rating: 3,
      status: 'completed',
      duration: '8 min',
      distance: '1.4 miles'
    }
  ]

  const filteredRides = rideHistory.filter(ride => {
    const matchesSearch = ride.from.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ride.to.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         ride.driver.toLowerCase().includes(searchTerm.toLowerCase())
    
    const matchesFilter = filterType === 'all' || 
                         (filterType === 'recent' && new Date(ride.date) > new Date('2025-01-13')) ||
                         (filterType === 'high-rated' && ride.rating >= 5)
    
    return matchesSearch && matchesFilter
  })

  const totalSpent = rideHistory.reduce((sum, ride) => sum + ride.fare, 0)
  const totalRides = rideHistory.length
  const averageRating = rideHistory.reduce((sum, ride) => sum + ride.rating, 0) / totalRides

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border px-4 py-4">
        <div className="flex items-center space-x-4">
          <Link to="/dashboard" className="p-2 hover:bg-background rounded-xl transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </Link>
          <Logo size="sm" linkTo="/dashboard" />
          <div>
            <h1 className="text-xl font-bold">Ride History</h1>
            <p className="text-textSecondary text-sm">Track all your rides and expenses</p>
          </div>
        </div>
      </header>

      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          {/* Stats */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <motion.div
              className="card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-primary/10 rounded-2xl text-primary">
                  <Car className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{totalRides}</p>
                  <p className="text-textSecondary text-sm">Total Rides</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              className="card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
            >
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-success/10 rounded-2xl text-success">
                  <DollarSign className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold">${totalSpent.toFixed(2)}</p>
                  <p className="text-textSecondary text-sm">Total Spent</p>
                </div>
              </div>
            </motion.div>

            <motion.div
              className="card"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <div className="flex items-center space-x-4">
                <div className="p-3 bg-warning/10 rounded-2xl text-warning">
                  <Star className="w-6 h-6" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{averageRating.toFixed(1)}</p>
                  <p className="text-textSecondary text-sm">Avg Rating</p>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col sm:flex-row gap-4 mb-8">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
              <input
                type="text"
                placeholder="Search rides..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input-field pl-12 w-full"
              />
            </div>
            
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-textSecondary" />
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="input-field pl-12 pr-8 appearance-none cursor-pointer"
              >
                <option value="all">All Rides</option>
                <option value="recent">Recent</option>
                <option value="high-rated">5 Star Rides</option>
              </select>
            </div>
          </div>

          {/* Ride List */}
          <div className="space-y-4">
            {filteredRides.map((ride, index) => (
              <motion.div
                key={ride.id}
                className="card hover:bg-surface/80 transition-colors"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                      <Car className="w-6 h-6 text-primary" />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <MapPin className="w-4 h-4 text-success" />
                        <span className="font-medium">{ride.from}</span>
                        <span className="text-textSecondary">→</span>
                        <MapPin className="w-4 h-4 text-error" />
                        <span className="font-medium">{ride.to}</span>
                      </div>
                      
                      <div className="flex items-center space-x-4 text-sm text-textSecondary">
                        <span>{ride.date} at {ride.time}</span>
                        <span>•</span>
                        <span>{ride.driver}</span>
                        <span>•</span>
                        <span>{ride.duration}</span>
                        <span>•</span>
                        <span>{ride.distance}</span>
                      </div>
                    </div>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-xl font-bold">${ride.fare.toFixed(2)}</p>
                    <div className="flex items-center space-x-1">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-4 h-4 ${
                            i < ride.rating ? 'text-warning fill-current' : 'text-textSecondary'
                          }`}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>

          {filteredRides.length === 0 && (
            <div className="text-center py-12">
              <Car className="w-16 h-16 text-textSecondary mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">No rides found</h3>
              <p className="text-textSecondary">
                {searchTerm ? 'Try adjusting your search terms' : 'You haven\'t taken any rides yet'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

export default RideHistoryPage
