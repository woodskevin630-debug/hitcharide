import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { MapPin, Clock, Car, Star, Menu, Bell, User, CreditCard, History, Settings } from 'lucide-react'
import { useAuthStore } from '../store/authStore'
import { useRideStore } from '../store/rideStore'
import MapComponent from '../components/MapComponent'
import Logo from '../components/Logo'

const DashboardPage = () => {
  const [showSidebar, setShowSidebar] = useState(false)
  const { user } = useAuthStore()
  const { currentRide } = useRideStore()

  const quickActions = [
    {
      title: 'Book a Ride',
      description: 'Get a ride now',
      icon: <Car className="w-6 h-6" />,
      link: '/book-ride',
      color: 'bg-primary'
    },
    {
      title: 'Ride History',
      description: 'View past trips',
      icon: <History className="w-6 h-6" />,
      link: '/history',
      color: 'bg-secondary'
    },
    {
      title: 'Payment',
      description: 'Manage cards',
      icon: <CreditCard className="w-6 h-6" />,
      link: '/payment',
      color: 'bg-accent'
    },
    {
      title: 'Profile',
      description: 'Account settings',
      icon: <User className="w-6 h-6" />,
      link: '/profile',
      color: 'bg-success'
    }
  ]

  const recentRides = [
    {
      id: 1,
      from: 'Downtown Office',
      to: 'Home',
      date: '2025-01-15',
      time: '6:30 PM',
      fare: '$12.50',
      rating: 5
    },
    {
      id: 2,
      from: 'Airport',
      to: 'Hotel Plaza',
      date: '2025-01-14',
      time: '2:15 PM',
      fare: '$28.75',
      rating: 4
    },
    {
      id: 3,
      from: 'Shopping Mall',
      to: 'Restaurant',
      date: '2025-01-13',
      time: '7:45 PM',
      fare: '$8.25',
      rating: 5
    }
  ]

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className="p-2 hover:bg-background rounded-xl transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
            
            <div>
              <h1 className="text-xl font-bold">
                Good {new Date().getHours() < 12 ? 'morning' : new Date().getHours() < 18 ? 'afternoon' : 'evening'}, {user?.firstName}!
              </h1>
              <p className="text-textSecondary text-sm">Ready for your next ride?</p>
            </div>
          </div>

          <div className="flex items-center space-x-3">
            <button className="p-2 hover:bg-background rounded-xl transition-colors relative">
              <Bell className="w-6 h-6" />
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-error rounded-full"></span>
            </button>
            
            <Link to="/profile" className="flex items-center space-x-2 hover:bg-background rounded-xl p-2 transition-colors">
              <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-semibold">
                  {user?.firstName?.[0]}{user?.lastName?.[0]}
                </span>
              </div>
            </Link>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <motion.aside
          className={`fixed inset-y-0 left-0 z-50 w-64 bg-surface border-r border-border transform transition-transform duration-300 ${
            showSidebar ? 'translate-x-0' : '-translate-x-full'
          } lg:relative lg:translate-x-0`}
          initial={false}
        >
          <div className="p-6">
            <div className="mb-8">
              <Logo size="md" linkTo="/dashboard" />
            </div>

            <nav className="space-y-2">
              <Link
                to="/dashboard"
                className="flex items-center space-x-3 px-4 py-3 rounded-2xl bg-primary/10 text-primary"
              >
                <Car className="w-5 h-5" />
                <span>Dashboard</span>
              </Link>
              
              <Link
                to="/book-ride"
                className="flex items-center space-x-3 px-4 py-3 rounded-2xl hover:bg-background transition-colors"
              >
                <MapPin className="w-5 h-5" />
                <span>Book Ride</span>
              </Link>
              
              <Link
                to="/history"
                className="flex items-center space-x-3 px-4 py-3 rounded-2xl hover:bg-background transition-colors"
              >
                <History className="w-5 h-5" />
                <span>Ride History</span>
              </Link>
              
              <Link
                to="/profile"
                className="flex items-center space-x-3 px-4 py-3 rounded-2xl hover:bg-background transition-colors"
              >
                <User className="w-5 h-5" />
                <span>Profile</span>
              </Link>
              
              <Link
                to="/settings"
                className="flex items-center space-x-3 px-4 py-3 rounded-2xl hover:bg-background transition-colors"
              >
                <Settings className="w-5 h-5" />
                <span>Settings</span>
              </Link>
            </nav>
          </div>
        </motion.aside>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {/* Current Ride Status */}
          {currentRide && (
            <motion.div
              className="card mb-6 gradient-bg text-white"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
            >
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Current Ride</h3>
                  <p className="opacity-90">Driver: {currentRide.driverName}</p>
                  <p className="opacity-90">ETA: {currentRide.eta} minutes</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">${currentRide.fare}</p>
                  <p className="opacity-90 capitalize">{currentRide.status}</p>
                </div>
              </div>
            </motion.div>
          )}

          <div className="grid lg:grid-cols-3 gap-6">
            {/* Quick Actions */}
            <div className="lg:col-span-1">
              <h2 className="text-2xl font-bold mb-6">Quick Actions</h2>
              <div className="grid grid-cols-2 lg:grid-cols-1 gap-4">
                {quickActions.map((action, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Link
                      to={action.link}
                      className="card hover:scale-105 transition-transform duration-200 block"
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`${action.color} p-3 rounded-2xl text-white`}>
                          {action.icon}
                        </div>
                        <div>
                          <h3 className="font-semibold">{action.title}</h3>
                          <p className="text-textSecondary text-sm">{action.description}</p>
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Map */}
            <div className="lg:col-span-2">
              <h2 className="text-2xl font-bold mb-6">Your Location</h2>
              <div className="card p-0 overflow-hidden h-96">
                <MapComponent />
              </div>
            </div>
          </div>

          {/* Recent Rides */}
          <div className="mt-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold">Recent Rides</h2>
              <Link to="/history" className="text-primary hover:text-primary/80">
                View All
              </Link>
            </div>

            <div className="grid gap-4">
              {recentRides.map((ride, index) => (
                <motion.div
                  key={ride.id}
                  className="card hover:bg-surface/80 transition-colors"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center">
                        <Car className="w-6 h-6 text-primary" />
                      </div>
                      <div>
                        <h3 className="font-semibold">{ride.from} → {ride.to}</h3>
                        <p className="text-textSecondary text-sm">
                          {ride.date} at {ride.time}
                        </p>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <p className="font-semibold text-lg">{ride.fare}</p>
                      <div className="flex items-center space-x-1">
                        {[...Array(5)].map((_, i) => (
                          <Star
                            key={i}
                            className={`w-4 h-4 ${
                              i < ride.rating ? 'text-warning fill-current' : 'text-textSecondary'
                            }`}
                          />
                        ))}
                      </div>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </main>
      </div>

      {/* Overlay for mobile sidebar */}
      {showSidebar && (
        <div
          className="fixed inset-0 bg-black/50 z-40 lg:hidden"
          onClick={() => setShowSidebar(false)}
        />
      )}
    </div>
  )
}

export default DashboardPage
