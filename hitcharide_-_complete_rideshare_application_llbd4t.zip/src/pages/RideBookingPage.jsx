import React, { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { MapPin, Navigation, Clock, DollarSign, Car, User, Star, Phone, ArrowLeft } from 'lucide-react'
import { Link } from 'react-router-dom'
import { useRideStore } from '../store/rideStore'
import MapComponent from '../components/MapComponent'
import Logo from '../components/Logo'

const RideBookingPage = () => {
  const [step, setStep] = useState('booking') // booking, selecting, confirmed, tracking
  const [pickup, setPickup] = useState('')
  const [destination, setDestination] = useState('')
  const [selectedRideType, setSelectedRideType] = useState('standard')
  const [selectedDriver, setSelectedDriver] = useState(null)
  const { bookRide, isBooking, currentRide } = useRideStore()

  const rideTypes = [
    {
      id: 'economy',
      name: 'Economy',
      description: 'Affordable rides',
      price: '$8.50',
      eta: '3-5 min',
      icon: '🚗'
    },
    {
      id: 'standard',
      name: 'Standard',
      description: 'Comfortable rides',
      price: '$12.75',
      eta: '2-4 min',
      icon: '🚙'
    },
    {
      id: 'premium',
      name: 'Premium',
      description: 'Luxury experience',
      price: '$18.90',
      eta: '5-7 min',
      icon: '🚗'
    },
    {
      id: 'xl',
      name: 'XL',
      description: 'Extra space',
      price: '$15.25',
      eta: '4-6 min',
      icon: '🚐'
    }
  ]

  const availableDrivers = [
    {
      id: 1,
      name: 'Sarah Johnson',
      rating: 4.9,
      reviews: 1247,
      eta: '2 min',
      car: 'Toyota Camry',
      plate: 'ABC-123',
      photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150'
    },
    {
      id: 2,
      name: 'Michael Chen',
      rating: 4.8,
      reviews: 892,
      eta: '3 min',
      car: 'Honda Accord',
      plate: 'XYZ-789',
      photo: 'https://images.pexels.com/photos/2379004/pexels-photo-2379004.jpeg?auto=compress&cs=tinysrgb&w=150'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      rating: 5.0,
      reviews: 2156,
      eta: '4 min',
      car: 'Nissan Altima',
      plate: 'DEF-456',
      photo: 'https://images.pexels.com/photos/1181686/pexels-photo-1181686.jpeg?auto=compress&cs=tinysrgb&w=150'
    }
  ]

  const handleBookRide = async () => {
    if (!pickup || !destination) return

    const rideData = {
      pickup,
      destination,
      rideType: selectedRideType,
      driverId: selectedDriver?.id
    }

    const result = await bookRide(rideData)
    if (result.success) {
      setStep('confirmed')
      setTimeout(() => setStep('tracking'), 2000)
    }
  }

  const handleDriverSelect = (driver) => {
    setSelectedDriver(driver)
    setStep('confirmed')
    setTimeout(() => setStep('tracking'), 2000)
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-surface border-b border-border px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link to="/dashboard" className="p-2 hover:bg-background rounded-xl transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </Link>
            <Logo size="sm" linkTo="/dashboard" />
            <h1 className="text-xl font-bold">Book a Ride</h1>
          </div>
          <div className="flex items-center space-x-2 text-textSecondary">
            <Clock className="w-4 h-4" />
            <span className="text-sm">{new Date().toLocaleTimeString()}</span>
          </div>
        </div>
      </header>

      <div className="flex flex-col lg:flex-row h-[calc(100vh-80px)]">
        {/* Booking Panel */}
        <div className="lg:w-96 bg-surface border-r border-border overflow-y-auto">
          <AnimatePresence mode="wait">
            {step === 'booking' && (
              <motion.div
                key="booking"
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className="p-6 space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-bold mb-6">Where to?</h2>
                  
                  {/* Location Inputs */}
                  <div className="space-y-4">
                    <div className="relative">
                      <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-success" />
                      <input
                        type="text"
                        placeholder="Pickup location"
                        value={pickup}
                        onChange={(e) => setPickup(e.target.value)}
                        className="input-field pl-12 w-full"
                      />
                    </div>
                    
                    <div className="relative">
                      <Navigation className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-error" />
                      <input
                        type="text"
                        placeholder="Where are you going?"
                        value={destination}
                        onChange={(e) => setDestination(e.target.value)}
                        className="input-field pl-12 w-full"
                      />
                    </div>
                  </div>
                </div>

                {/* Ride Types */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Choose your ride</h3>
                  <div className="space-y-3">
                    {rideTypes.map((type) => (
                      <button
                        key={type.id}
                        onClick={() => setSelectedRideType(type.id)}
                        className={`w-full p-4 rounded-2xl border transition-all ${
                          selectedRideType === type.id
                            ? 'border-primary bg-primary/10'
                            : 'border-border hover:border-primary/50'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <span className="text-2xl">{type.icon}</span>
                            <div className="text-left">
                              <h4 className="font-semibold">{type.name}</h4>
                              <p className="text-textSecondary text-sm">{type.description}</p>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="font-bold">{type.price}</p>
                            <p className="text-textSecondary text-sm">{type.eta}</p>
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                <button
                  onClick={() => setStep('selecting')}
                  disabled={!pickup || !destination}
                  className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Find Drivers
                </button>
              </motion.div>
            )}

            {step === 'selecting' && (
              <motion.div
                key="selecting"
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20 }}
                className="p-6 space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-bold mb-2">Choose your driver</h2>
                  <p className="text-textSecondary">Available drivers near you</p>
                </div>

                <div className="space-y-4">
                  {availableDrivers.map((driver) => (
                    <button
                      key={driver.id}
                      onClick={() => handleDriverSelect(driver)}
                      className="w-full p-4 rounded-2xl border border-border hover:border-primary transition-all hover:scale-105"
                    >
                      <div className="flex items-center space-x-4">
                        <img
                          src={driver.photo}
                          alt={driver.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div className="flex-1 text-left">
                          <h4 className="font-semibold">{driver.name}</h4>
                          <div className="flex items-center space-x-2 text-sm text-textSecondary">
                            <Star className="w-4 h-4 text-warning fill-current" />
                            <span>{driver.rating}</span>
                            <span>({driver.reviews})</span>
                          </div>
                          <p className="text-sm text-textSecondary">{driver.car} • {driver.plate}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold text-primary">{driver.eta}</p>
                          <p className="text-textSecondary text-sm">away</p>
                        </div>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}

            {step === 'confirmed' && (
              <motion.div
                key="confirmed"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="p-6 text-center space-y-6"
              >
                <div className="text-6xl mb-4">✅</div>
                <h2 className="text-2xl font-bold">Ride Confirmed!</h2>
                <p className="text-textSecondary">
                  {selectedDriver?.name} is on the way
                </p>
                
                {selectedDriver && (
                  <div className="card">
                    <div className="flex items-center space-x-4">
                      <img
                        src={selectedDriver.photo}
                        alt={selectedDriver.name}
                        className="w-16 h-16 rounded-full object-cover"
                      />
                      <div className="flex-1 text-left">
                        <h3 className="font-semibold text-lg">{selectedDriver.name}</h3>
                        <div className="flex items-center space-x-2 text-textSecondary">
                          <Star className="w-4 h-4 text-warning fill-current" />
                          <span>{selectedDriver.rating}</span>
                        </div>
                        <p className="text-textSecondary">{selectedDriver.car}</p>
                      </div>
                    </div>
                  </div>
                )}
              </motion.div>
            )}

            {step === 'tracking' && (
              <motion.div
                key="tracking"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 20 }}
                className="p-6 space-y-6"
              >
                <div>
                  <h2 className="text-2xl font-bold mb-2">Driver En Route</h2>
                  <p className="text-textSecondary">ETA: 2 minutes</p>
                </div>

                {selectedDriver && (
                  <div className="card">
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <img
                          src={selectedDriver.photo}
                          alt={selectedDriver.name}
                          className="w-12 h-12 rounded-full object-cover"
                        />
                        <div>
                          <h3 className="font-semibold">{selectedDriver.name}</h3>
                          <p className="text-textSecondary text-sm">{selectedDriver.car}</p>
                        </div>
                      </div>
                      <button className="p-3 bg-success rounded-full text-white">
                        <Phone className="w-5 h-5" />
                      </button>
                    </div>
                    
                    <div className="text-center py-4 bg-background rounded-2xl">
                      <p className="text-2xl font-bold">{selectedDriver.plate}</p>
                      <p className="text-textSecondary text-sm">License Plate</p>
                    </div>
                  </div>
                )}

                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-background rounded-2xl">
                    <span className="text-textSecondary">Pickup</span>
                    <span className="font-medium">{pickup}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-background rounded-2xl">
                    <span className="text-textSecondary">Destination</span>
                    <span className="font-medium">{destination}</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-background rounded-2xl">
                    <span className="text-textSecondary">Fare</span>
                    <span className="font-bold text-lg">$12.75</span>
                  </div>
                </div>

                <button className="btn-secondary w-full">
                  Cancel Ride
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Map */}
        <div className="flex-1">
          <MapComponent />
        </div>
      </div>
    </div>
  )
}

export default RideBookingPage
