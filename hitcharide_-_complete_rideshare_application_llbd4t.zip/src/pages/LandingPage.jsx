import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { Car, MapPin, Clock, Shield, Star, Users } from 'lucide-react'
import Logo from '../components/Logo'

const LandingPage = () => {
  const features = [
    {
      icon: <Car className="w-8 h-8" />,
      title: "Instant Rides",
      description: "Get a ride in minutes with our network of verified drivers"
    },
    {
      icon: <MapPin className="w-8 h-8" />,
      title: "Real-time Tracking",
      description: "Track your ride in real-time and share your trip with loved ones"
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "24/7 Availability",
      description: "Need a ride? We're here around the clock, every day of the year"
    },
    {
      icon: <Shield className="w-8 h-8" />,
      title: "Safe & Secure",
      description: "All drivers are background-checked and rides are insured"
    }
  ]

  const stats = [
    { number: "10M+", label: "Happy Riders" },
    { number: "500K+", label: "Trusted Drivers" },
    { number: "100+", label: "Cities" },
    { number: "4.9", label: "Average Rating" }
  ]

  return (
    <div className="min-h-screen">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 glass-effect">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <Logo size="md" />
            </motion.div>
            
            <motion.div 
              className="flex items-center space-x-4"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Link to="/login" className="text-textSecondary hover:text-text transition-colors">
                Sign In
              </Link>
              <Link to="/signup" className="btn-primary">
                Get Started
              </Link>
            </motion.div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-5xl lg:text-7xl font-bold leading-tight mb-6">
                Your Ride,
                <span className="gradient-bg bg-clip-text text-transparent"> Your Way</span>
              </h1>
              <p className="text-xl text-textSecondary mb-8 leading-relaxed">
                Experience the future of transportation with Hitcharide. Safe, reliable, and affordable rides at your fingertips.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/signup" className="btn-primary text-lg px-8 py-4">
                  Start Riding
                </Link>
                <Link to="/signup?driver=true" className="btn-secondary text-lg px-8 py-4">
                  Become a Driver
                </Link>
              </div>
            </motion.div>
            
            <motion.div
              className="relative"
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="relative z-10">
                <img 
                  src="https://images.pexels.com/photos/3807755/pexels-photo-3807755.jpeg?auto=compress&cs=tinysrgb&w=800" 
                  alt="Modern rideshare experience"
                  className="rounded-3xl shadow-2xl"
                />
              </div>
              <div className="absolute -top-4 -right-4 w-full h-full gradient-bg rounded-3xl opacity-20 animate-pulse-glow"></div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <motion.div
                key={index}
                className="text-center"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="text-4xl lg:text-5xl font-bold gradient-bg bg-clip-text text-transparent mb-2">
                  {stat.number}
                </div>
                <div className="text-textSecondary">{stat.label}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <motion.div
            className="text-center mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl lg:text-5xl font-bold mb-6">
              Why Choose <span className="gradient-bg bg-clip-text text-transparent">Hitcharide?</span>
            </h2>
            <p className="text-xl text-textSecondary max-w-3xl mx-auto">
              We're revolutionizing transportation with cutting-edge technology and unmatched service quality.
            </p>
          </motion.div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => (
              <motion.div
                key={index}
                className="card hover:scale-105 transition-transform duration-300"
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: index * 0.1 }}
                viewport={{ once: true }}
              >
                <div className="text-primary mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-textSecondary">{feature.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            className="card gradient-bg p-12"
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2 className="text-4xl font-bold text-white mb-6">
              Ready to Transform Your Commute?
            </h2>
            <p className="text-xl text-white/90 mb-8">
              Join millions of riders who trust Hitcharide for their daily transportation needs.
            </p>
            <Link to="/signup" className="bg-white text-primary hover:bg-gray-100 font-semibold py-4 px-8 rounded-2xl transition-all duration-200 hover:scale-105 inline-block">
              Get Started Today
            </Link>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-border">
        <div className="max-w-7xl mx-auto text-center">
          <Logo size="sm" className="justify-center mb-4" />
          <p className="text-textSecondary">
            © 2025 Hitcharide Rentals LLC. All rights reserved. Your ride, your way.
          </p>
        </div>
      </footer>
    </div>
  )
}

export default LandingPage
