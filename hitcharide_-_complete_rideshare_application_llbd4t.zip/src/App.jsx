import React from 'react'
import { Routes, Route, Navigate } from 'react-router-dom'
import { useAuthStore } from './store/authStore'
import LandingPage from './pages/LandingPage'
import LoginPage from './pages/LoginPage'
import SignupPage from './pages/SignupPage'
import OnboardingPage from './pages/OnboardingPage'
import DashboardPage from './pages/DashboardPage'
import RideBookingPage from './pages/RideBookingPage'
import DriverDashboard from './pages/DriverDashboard'
import RideHistoryPage from './pages/RideHistoryPage'
import ProfilePage from './pages/ProfilePage'

function App() {
  const { user, isAuthenticated } = useAuthStore()

  return (
    <div className="min-h-screen bg-background">
      <Routes>
        <Route path="/" element={<LandingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />
        
        {/* Protected Routes */}
        <Route path="/onboarding" element={
          isAuthenticated ? <OnboardingPage /> : <Navigate to="/login" />
        } />
        <Route path="/dashboard" element={
          isAuthenticated ? <DashboardPage /> : <Navigate to="/login" />
        } />
        <Route path="/book-ride" element={
          isAuthenticated ? <RideBookingPage /> : <Navigate to="/login" />
        } />
        <Route path="/driver" element={
          isAuthenticated && user?.role === 'driver' ? <DriverDashboard /> : <Navigate to="/dashboard" />
        } />
        <Route path="/history" element={
          isAuthenticated ? <RideHistoryPage /> : <Navigate to="/login" />
        } />
        <Route path="/profile" element={
          isAuthenticated ? <ProfilePage /> : <Navigate to="/login" />
        } />
      </Routes>
    </div>
  )
}

export default App
