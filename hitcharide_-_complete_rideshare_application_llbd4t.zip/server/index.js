
const express = require('express')
const cors = require('cors')
const http = require('http')
const socketIo = require('socket.io')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')
const { v4: uuidv4 } = require('uuid')

const app = express()
const server = http.createServer(app)
const io = socketIo(server, {
  cors: {
    origin: "http://localhost:5173",
    methods: ["GET", "POST"]
  }
})

// Middleware
app.use(cors())
app.use(express.json())

// In-memory database (replace with real database in production)
const users = []
const rides = []
const drivers = []

// JWT Secret (use environment variable in production)
const JWT_SECRET = 'your-secret-key'

// Auth middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization']
  const token = authHeader && authHeader.split(' ')[1]

  if (!token) {
    return res.status(401).json({ message: 'Access token required' })
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ message: 'Invalid token' })
    }
    req.user = user
    next()
  })
}

// Auth Routes
app.post('/api/auth/signup', async (req, res) => {
  try {
    const